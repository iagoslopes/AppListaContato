package iago.slopes.applistacontato.adapters

class AdapterContatos {
}