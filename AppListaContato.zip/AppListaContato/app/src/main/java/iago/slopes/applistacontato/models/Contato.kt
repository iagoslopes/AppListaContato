package iago.slopes.applistacontato.models

class Contato (
    var nome: String,
    var email: String,
    var telefone: String,
    var endereco: String,
    var foto: String
)